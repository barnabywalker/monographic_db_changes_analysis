
setGeneric('add_heatmap', function(object, ...) standardGeneric('add_heatmap'))

setGeneric('map_to_colors', function(object, ...) standardGeneric('map_to_colors'))

setGeneric('set_component_height', function(object, ...) standardGeneric('set_component_height'))

setGeneric('draw_heatmap_body', function(object, ...) standardGeneric('draw_heatmap_body'))

setGeneric('column_order', function(object, ...) standardGeneric('column_order'))

setGeneric('draw_annotation_legend', function(object, ...) standardGeneric('draw_annotation_legend'))

setGeneric('component_height', function(object, ...) standardGeneric('component_height'))

setGeneric('make_layout', function(object, ...) standardGeneric('make_layout'))

setGeneric('draw_heatmap_legend', function(object, ...) standardGeneric('draw_heatmap_legend'))

setGeneric('heatmap_legend_size', function(object, ...) standardGeneric('heatmap_legend_size'))

setGeneric('annotation_legend_size', function(object, ...) standardGeneric('annotation_legend_size'))

setGeneric('prepare', function(object, ...) standardGeneric('prepare'))

setGeneric('draw_annotation', function(object, ...) standardGeneric('draw_annotation'))

setGeneric('get_color_mapping_param_list', function(object, ...) standardGeneric('get_color_mapping_param_list'))

setGeneric('draw_dimnames', function(object, ...) standardGeneric('draw_dimnames'))

setGeneric('color_mapping_legend', function(object, ...) standardGeneric('color_mapping_legend'))

setGeneric('draw', function(object, ...) standardGeneric('draw'))

setGeneric('make_row_cluster', function(object, ...) standardGeneric('make_row_cluster'))

setGeneric('draw_title', function(object, ...) standardGeneric('draw_title'))

setGeneric('make_column_cluster', function(object, ...) standardGeneric('make_column_cluster'))

setGeneric('component_width', function(object, ...) standardGeneric('component_width'))

setGeneric('column_dend', function(object, ...) standardGeneric('column_dend'))

setGeneric('get_color_mapping_list', function(object, ...) standardGeneric('get_color_mapping_list'))

setGeneric('row_order', function(object, ...) standardGeneric('row_order'))

setGeneric('draw_dend', function(object, ...) standardGeneric('draw_dend'))

setGeneric('draw_heatmap_list', function(object, ...) standardGeneric('draw_heatmap_list'))

setGeneric('row_dend', function(object, ...) standardGeneric('row_dend'))
